package javax.practice3;

import java.util.Scanner;

public class Permutations {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		String input= sc.nextLine();
		if(input.length()==2)
		{
			System.out.print(input);
			System.out.print(" ");
			StringBuilder sb=new StringBuilder();
			System.out.print(sb.append(input).reverse());			
		}
		else if(input.length()==3)
		{
		   	
			
			
		}
		
		
	}
	
}

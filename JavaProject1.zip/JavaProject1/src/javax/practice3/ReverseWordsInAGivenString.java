package javax.practice3;

import java.util.Scanner;

public class ReverseWordsInAGivenString {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		String input=sc.nextLine();
		String[] strArray=input.split("");
		
		for(int i=strArray.length-1;i>=0;i--)
		{
			
			System.out.print(input.charAt(i));
			/*if(i>0)
			System.out.print(".");*/
			
		}
		
		
		
	}
	
}

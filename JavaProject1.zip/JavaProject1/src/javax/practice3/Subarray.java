package javax.practice3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Subarray {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int notc = sc.nextInt();
		//int sum = sc.nextInt();
		//List<String> rslt = new ArrayList<String>();
		for (int j = 0; j < notc; j++) {
			int size = sc.nextInt();
			int sum = sc.nextInt();
			List<Integer> plst = new ArrayList<Integer>();
			for (int i = 0; i < size; i++) {
				plst.add(sc.nextInt());
			}
			
			getResult(plst, size, sum);
		}

	}

	private static void getResult(List<Integer> plst, int size, int totalSum) 
	{
	
		for(int i=0;i<size;i++)
		{
			int flag=0;
			int sum=0;
			for(int j=0;j<size;j++)
			{
				if(i != j)
				{
					sum=sum+plst.get(i)+plst.get(j);
					if(sum==totalSum)
					{	System.out.println("Result="+(i+1)+" and "+(j+1));
						flag=1;
						break;
					}
					
				}
				if(flag==1)
					break;
				if (i == size - 1)
					System.out.println("No Result possiable");
			
			}
			
			
		}
		
		
	}
}

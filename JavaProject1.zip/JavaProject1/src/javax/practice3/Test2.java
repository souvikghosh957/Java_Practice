package javax.practice3;

public class Test2 {

}

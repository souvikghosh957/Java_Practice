package javax.practice;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public  class AbsCls {

	public static void main(String[] args) {
		
		String sc=new String("abc hello");
		System.out.println("hello".equals("hell"+"o"));
		System.out.println(sc.indexOf("l"));
		char[] chars=sc.toCharArray();
		System.out.println(chars);
		String[] sttr=sc.split("");
		System.out.println(sttr[0]);
		List<String> lst=Arrays.asList(sttr);
		System.out.println(lst);
		List<String> lst1=lst.stream().filter(n->!n.equals(" ")).collect(Collectors.toList());
		System.out.println(lst1);
	}
}

package javax.practice;

 interface DeclStaff {

	public static final int val=3;
	void doMeth(int t);
}
 public class ImplClass implements DeclStaff
{
	public static void main(String[] args) {
		int t=5;
		new ImplClass().doMeth(++t);	
	}

	@Override
	public void doMeth(int t) {
		t+=val + ++t;
		System.out.println("Result="+t);
	}
	
}
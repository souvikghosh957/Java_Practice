package javax.practice;

public class DemoTest {
	int a=6;
	static int b=23;
	private static int c=55;
	void outerMethod()
	{
		System.out.println("Outer method value="+InnerClass.d);
	}
	static class InnerClass
	{	
		static int d=66;
		public void method1()
		{
			//System.out.println("1st-----" +a);
			System.out.println("1st-----" +b);
			System.out.println("1st-----" +c);	
		}	
	}
	
	public static void main(String[] args) 
	{	
		DemoTest demoTest= new DemoTest();
		demoTest.outerMethod();
		
		DemoTest.InnerClass inc=new DemoTest.InnerClass();
		System.out.println("d's value="+inc.d);
		inc.method1();
		
	}

}

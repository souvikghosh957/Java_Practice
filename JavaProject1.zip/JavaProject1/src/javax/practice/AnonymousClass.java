package javax.practice;



interface InterfaceOne
{
	public void methodOne();
	InterfaceOne obj1=new InterfaceOne()
	{
		public void methodOne()
		{
			System.out.println("Inside methodOne implementation 1");
		}
	};
	
}


public class AnonymousClass implements InterfaceOne
{
	public static void main(String[] args) 
	{
		/*InterfaceOne obj1=new InterfaceOne()
		{
			public void methodOne()
			{
				System.out.println("Inside methodOne implementation 1");
			}
		};*/
		
		
		
		
		InterfaceOne obj2=new InterfaceOne()
		{
			public void methodOne()
			{
				System.out.println("Inside methodOne implementation 2'");
			}
		};

		obj1.methodOne();		
		obj2.methodOne();
		
		InterfaceOne obj3=new AnonymousClass();
		obj3.methodOne();
	}

	@Override
	public void methodOne() {
		
		System.out.println("Inside methodOne implementation 2");
	}
	
	
	
}

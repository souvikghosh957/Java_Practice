package javax.practice;

class Demo2 {

	
	public static int method1()
	{
		return 5;
	}
}

class Demo3 extends Demo2 {

	
	public static int method1()
	{
		return 10;
	}
	
	public int method2()
	{
		return 15;
	}

}



public class DemoRun {

public static void main(String[] args) {
	
	Demo3 d = new Demo3();
	int a = (d).method1();
	System.out.println("Runtime output is :" +a);
	
}


	
	
}



package javax.practice;

public class Demo {

	public Demo()
	{
		
	}
	
	protected void method1()
	{
		System.out.println("This is demo method 1");
	}
	public static void main(String[] args) {

		/*Scanner sc=new Scanner(System.in);
		String name=sc.nextLine();
		int a = Integer.parseInt(name);
		System.out.println("Your name is "+name);
		//Creating Object class
*/		
		Object obj=new Object()
				{
					public int hashCode()
					{
						return 42;
					}
				};
		
				System.out.println(obj.hashCode());
			
	}
	
	
	
}

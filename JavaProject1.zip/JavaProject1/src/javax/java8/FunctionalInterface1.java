package javax.java8;

@FunctionalInterface
public interface FunctionalInterface1 {
	
	void concatAge(String s, int a);
	default void defaultMeth()
	{
		System.out.println("Inside defaultMeth");
	}
}

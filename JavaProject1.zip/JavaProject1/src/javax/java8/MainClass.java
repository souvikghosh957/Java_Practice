package javax.java8;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class MainClass implements FunctionalInterface1{

	public static void main(String[] args) {
		
		FunctionalInterface1 fi = (String s,int age)-> System.out.println(""+s+" "+age);
		
		fi.concatAge("Jhon", 24);
	
		FunctionalInterface1 mc=new MainClass();
		mc.defaultMeth();
	//	System.out.println(mc.concatAge("",23));
		
		
		System.out.println("-----------------------------------------------------------------------------------------");
		
		
		List<String> arlst= Arrays.asList("John", "Virat", "Sachin", "Srk");
		arlst.forEach(n->{System.out.println(n.toUpperCase());});
		
		List<String> rslst=arlst.stream().map(x->x+x).collect(Collectors.toList());
		System.out.println(rslst);
		
		List<String> fltr=arlst.stream().filter(x->x.length()>4).collect(Collectors.toList());
		System.out.println(fltr);
		
		Set<String> srted=arlst.stream().sorted().collect(Collectors.toSet());
		System.out.println(srted);
		
		System.out.println(arlst.stream().anyMatch(s->s.equals("Srk")));
		
		String[] strArray =new String[10];
		strArray[0]="Abc";
		strArray[1]="def";
		strArray[2]="ghi";
		
		
		
		Optional<String> op= Optional.ofNullable(strArray[1]);
		op.ifPresent(optnl->System.out.println(optnl));
		System.out.println(op.orElse("No value present"));
		
		
		
		
		/*if(op.isPresent())
		{
			System.out.println(strArray[1].length());
			System.out.println(op.get());
		}
		else
		{
			System.out.println("Null Value");
		}*/
		
		
		
	//	System.out.println(strArray[5].length());
		
		
		
	}
	
	@Override
	public void concatAge(String s, int a) {
		
		}

}

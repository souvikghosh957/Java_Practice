package javax.exams;



import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Increff {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int nod = sc.nextInt(); 	      //The number of days for which the delivery is to be made.
		List<String> rslt = new ArrayList<String>();
		for (int j = 0; j < nod; j++) {
			int nop = sc.nextInt();      //  The number of pies
			List<Integer> plst = new ArrayList<Integer>();
			for (int i = 0; i < nop; i++) {
				plst.add(sc.nextInt());   // Storing the weight of each pie in a list.
			}
			int delv = sc.nextInt();    //The weight of pie in pounds which needs to delivered.

			rslt.add(getResult(plst, nop, delv));
		}
		rslt.forEach(n -> System.out.println(n));
	}

	private static String getResult(List<Integer> plst, int nop, int delv) {
		
		int sum = 0;
		int flag = 0;
		String rslt = "";
		for (int m = 0; m < nop; m++) {
			sum = sum + plst.get(m);
			if(sum==delv)
			    return "YES";
		}
		if (sum == delv) {
			return "YES";
		} else {
			for (int i = 0; i < nop; i++) {
				if (plst.get(i) <= delv) {
					if (plst.get(i) == delv) {
						rslt = "YES";
						break;
					}
					for (int j = 0; j < nop; j++) {
						if (i != j && (plst.get(i) + plst.get(j) == delv)) {

							rslt = "YES";
							flag = 1;
							break;

						}

					}
					if (flag == 1)
						break;
				}
				if (i == nop - 1)
					rslt = "NO";
			}
			return rslt;
		}

	}
}

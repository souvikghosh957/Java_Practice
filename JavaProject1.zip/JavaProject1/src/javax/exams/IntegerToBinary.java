package javax.exams;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class IntegerToBinary {

	public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
		int testCases=sc.nextInt();
		List<Integer> arlst=new ArrayList<Integer>();
		for(int i=0;i<testCases;i++)
		{
			arlst.add(sc.nextInt());
		}
		IntegerToBinary itb=new IntegerToBinary();
		
		itb.getResult(arlst);
		
		
		
		/*int n=sc.nextInt();
		String binaryString= Integer.toBinaryString(n);
		
		char[] charArray=new char[binaryString.length()];
		charArray=binaryString.toCharArray();
		int count=0;
		for(int i=0;i<charArray.length;i++)
		{
			if(charArray[i]=='1')
			{
				count++;
			}
		}
		System.out.println("Number of 1's is "+count);
		*/
	}

	private void getResult(List<Integer> arlst) {
		
		arlst.forEach(n->{String binaryString= Integer.toBinaryString(n);
		
		char[] charArray=new char[binaryString.length()];
		charArray=binaryString.toCharArray();
		int count=0;
		for(int i=0;i<charArray.length;i++)
		{
			if(charArray[i]=='1')
			{
				count++;
			}
		}
		if(count%2!=0)
			{
				
			
			}});
		
		
	
		
	}

}

package javax.exams;


public class Exam1 {

	public static void main(String[] args) 
	{
		
		
	}
}

package javax.practice2;

public final class ParentCls {

	private static String s="Hello";
	 
	 public String getS() {
		return s;
	}

	public void setS(String s) {
		this.s = s;
	}

	public void methodTwo()
	 {
		 System.out.println("Inside Method two");
	 }
	
	public static void main(String[] args) {
		s="Hi";
	}
	
	
}

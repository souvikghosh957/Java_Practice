package javax.practice2;


class Complex { 

  private double re, im;    
  public  Complex()
    {
    	
    }
  public  Complex(int a,int b)
  {
  	this.re=a;
  	this.im=b;
  }

  
    Object on=new Object();
  @Override
public String toString() {
	return ""+re+"+"+"i"+im;
}


/*  public String toString() { 
        return "(" + re + " + " + im + "i)"; 
    } 
*/    Complex(Complex c) { 
        re = c.re; 
        im = c.im; 
    } 
} 
  
public class Test3{ 
    public static void main(String[] args) { 
        Complex c1 = new Complex(1,5); 
        Complex c2 = new Complex(c1); 
        System.out.println(c2); 
        System.out.println(c1); 
    } 
} 
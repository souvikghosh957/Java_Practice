package javax.practice2;

import javax.practice.AbsCls;

public class MainClass extends AbsCls {
	//abstract void abstractMethod();
	
	public MainClass()
	{
		
	}
	public MainClass(int a, int b)
	{
		System.out.println(a+"+"+b);
	}
	
	
	public static void method1()
	{
		System.out.println("Inside method one");
		//return true;
	}
	
	public void method2()
	{
		method1();
	}

	public static void main(String[] args)
	{
		
		method1();
		MainClass m=new MainClass();
		String str="ABCD";
		System.out.println(str.substring(1));
		System.out.println(str.substring(0,1));
		
	}

}

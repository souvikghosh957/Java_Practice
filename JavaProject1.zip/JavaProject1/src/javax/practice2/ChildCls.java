package javax.practice2;

import javax.practice.Demo;

public class ChildCls extends Demo {

	private int x=10;
	public void methOne()
	{
		System.out.println("Inside meth one");
	}
	
	
	
	public static void main(String[] args) 
	{
		ChildCls chld=new ChildCls();
		System.out.println(chld.x);
		ParentCls pcl=new ParentCls();
		pcl.methodTwo();
		Demo dm=new Demo();
		chld.method1();
		
	}
}

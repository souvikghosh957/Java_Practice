package javax.collectionDemo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class ListExample {
	
	public static void main(String[] args) {
		
		List<Integer> al= new ArrayList<Integer>();
		al.add(10);
		al.add(1,5);
		al.add(1,6);
		
		Iterator<Integer> it=al.iterator();
		ListIterator<Integer> lit=al.listIterator(al.size());
	//	System.out.println(al.contains(6));
	//	System.out.println(al.get(1).hashCode());
		System.out.println(al);
		al.set(1, 100);
		System.out.println(al);
		
		while(it.hasNext())
		{
			System.out.print(it.next()+" ");
		}
		
		while(lit.hasPrevious())
		{
			System.out.print(lit.previous()+" ");
		}
		
		ConcurrentModificationException c;
		List ll=new LinkedList<>();
		ll.add(1);
		ll.add("as");
		ll.add(BigDecimal.valueOf(7.9));
		ll.add(1,"Dog");

		ListIterator litr=ll.listIterator();
		ll.add(1,"Dog"); //Gives concurrent modification exception

		while(litr.hasNext())
		{
			System.out.println(litr.next());
		}
		
		Collections.sort(al,Collections.reverseOrder());
		System.out.println(al);
	}

}

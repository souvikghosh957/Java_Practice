package javax.collectionDemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ComparatorExmpl implements Comparator<ComparatorExmpl> {

	private Integer id;
	private String name;

	ComparatorExmpl() {

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ComparatorExmpl(Integer id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	@Override
	public int compare(ComparatorExmpl o1, ComparatorExmpl o2) {
		return o1.getId().compareTo(o2.getId());
	}

	static class SortByMultipleFields implements Comparator<ComparatorExmpl> {

		@Override
		public int compare(ComparatorExmpl o1, ComparatorExmpl o2) {

			int idCmpr = o1.getId().compareTo(o2.getId());
			int nameCmp = o1.getName().compareTo(o2.getName());

			if (idCmpr == 0) {
				return (nameCmp == 0 ? idCmpr : nameCmp);
			} else
				return idCmpr;

		}

	}

	public static void main(String[] args) {

		ComparatorExmpl ce = new ComparatorExmpl(1, "Souvik");
		ComparatorExmpl ce1 = new ComparatorExmpl(2, "Kumar");
		ComparatorExmpl ce2 = new ComparatorExmpl(1, "Ghosh");

		ArrayList<ComparatorExmpl> al = new ArrayList<ComparatorExmpl>();
		al.add(ce);
		al.add(ce1);
		al.add(ce2);
		Collections.sort(al, new ComparatorExmpl());
		al.forEach(n -> {
			System.out.println(n.getId() + " " + n.getName());
		});

		System.out.println("Soring by two fields...");

		Collections.sort(al, new SortByMultipleFields());
		al.forEach(n -> {
			System.out.println(n.getId() + " " + n.getName());
		});

	}

}

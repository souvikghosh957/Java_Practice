package javax.collectionDemo;

import java.util.ArrayList;
import java.util.Collections;

public class ComparableExmpl implements Comparable<ComparableExmpl>{
	
	private Integer id;
	private String name;
	public ComparableExmpl(Integer id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int compareTo(ComparableExmpl o) {
	
		return	-1*(this.id.compareTo(o.getId()));		
		
	}


	@Override
	public String toString() {
		return "ComparableExmpl [id=" + id + ", name=" + name + "]";
	}

	public static void main(String[] args) 
	{
		ComparableExmpl ce=new ComparableExmpl(3,"Souvik");
		ComparableExmpl ce1=new ComparableExmpl(2,"Kumar");
		ComparableExmpl ce2=new ComparableExmpl(1,"Xhosh");
		ArrayList<ComparableExmpl> al=new ArrayList<ComparableExmpl>();
		al.add(ce);
		al.add(ce1);
		al.add(ce2);
		Collections.sort(al);
		al.forEach(n->{System.out.println(n.getId()+" "+n.getName());});
		
	}



	}

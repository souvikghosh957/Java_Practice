package javax.collectionDemo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.TreeSet;

public class SetExample {

	public static void main(String[] args) 
	{
		
		HashSet hs=new HashSet<Integer>();
		LinkedHashSet<String> hs2=new LinkedHashSet<String>();
		TreeSet<String> ts=new TreeSet<String>();
		HashMap<Integer, String> hm=new HashMap<Integer, String>();
		hm.put(1,"S");
		hm.put(2, "G");
		hm.put(3,"R");
		hm.put(4, "D");
		hm.put(3, "S");
		Iterator it=hm.entrySet().iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		for(Map.Entry ent:hm.entrySet())
		{
			System.out.println(ent.getKey()+" "+ent.getValue());
		}
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		System.out.println("-------------------------------------------------");
		
		
		hs.add(1);
		hs.add(2);
		hs.add(3);
		hs.add(1);
		hs.add(null);
		System.out.println(hs);
		hs2.add("B");
		hs2.add("V");
		hs2.add("A");
		hs2.add("C");
		System.out.println(hs2);
		ts.add("B");
		ts.add("V");
		ts.add("A");
		ts.add("C");
		System.out.println(ts);
		Iterator it1=ts.descendingIterator();
		while(it1.hasNext())
		System.out.println(it1.next());
	
		
	}
}

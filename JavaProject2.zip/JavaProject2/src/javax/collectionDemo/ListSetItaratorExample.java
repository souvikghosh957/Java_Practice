package javax.collectionDemo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class ListSetItaratorExample {

	public static void main(String[] args) 
	{
		List<String> arryLst=new ArrayList<String>();
		arryLst.add("Amar");
		arryLst.add("Akhmal");
		arryLst.add("Anthani");
		System.out.println(arryLst.remove("Anthani"));
		//System.out.println(arryLst);
		//Collections.sort(arryLst);
		System.out.println(arryLst);
		ListIterator it=arryLst.listIterator(arryLst.size());
		while(it.hasPrevious())
		{
			System.out.println(it.previous());
		}
		Set<String> st=new HashSet<String>();
		st.add("1");
		st.remove("1");
		System.out.println(st);
		Map<Integer, String> hashMap=new HashMap<Integer, String>();
		hashMap.put(1, "P");
		hashMap.put(2, "Q");
		hashMap.put(1, "R");
		System.out.println(hashMap);
		for(HashMap.Entry<Integer,String> itrr:hashMap.entrySet())
		{
			System.out.println(itrr.getKey()+" "+itrr.getValue());
			//System.out.println(itrr.getValue());

		}
		/*while(itrr.hasNext())
		{
			System.out.println(itrr.next());
		}
*/		
		
		
	}
	
	
}

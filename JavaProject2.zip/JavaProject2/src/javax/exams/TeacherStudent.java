package javax.exams;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TeacherStudent {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int testCases = sc.nextInt();
		for (int tc = 0; tc < testCases; tc++) {
			int n = sc.nextInt();
			int k = sc.nextInt();
			List<Integer> lst = new ArrayList<Integer>();
			for (int i = 0; i < n; i++) {
				lst.add(sc.nextInt());
			}
			System.out.println(getResult(lst, k));

		}

	}

	private static int getResult(List<Integer> lst, int k) {
		int c1 = 0, c2 = 0, c3 = 1;
		for (int i = 0; i < lst.size(); i++) {
			for (int j = i; j < lst.size(); j++) {
				if (lst.get(j) % 4 == 0) {
					if (lst.get(j) < k)
						c1++;
					else if (lst.get(j) == k)
						c2++;
					else
						c3++;
				} else if (lst.get(j) % 4 == 1) {
					if (1 < k)
						c1++;
					else if (1 == k)
						c2++;
					else
						c3++;
				} else if (lst.get(j) % 4 == 2) {
					if (lst.get(j) + 1 < k)
						c1++;
					else if (lst.get(j) + 1 == k)
						c2++;
					else
						c3++;
				} else if (lst.get(j) % 4 == 3) {
					if (0 < k)
						c1++;
					else if (0 == k)
						c2++;
					else
						c3++;
				}

			}

		}

		int result = (int) Math.pow(c1 + c2 + c3, 2);
		return result;
	}

}

package javax.exams;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class BinaryMadness {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int testNum = 0;
		if (sc.hasNext()) {
			testNum = sc.nextInt(); // Taking input of the number of test cases
		}
		List<String> result = new ArrayList<String>();

		for (int test = 0; test < testNum; test++) {

			if (sc.hasNextBigInteger()) {

				BigInteger deciNum = sc.nextBigInteger(); // Inputed Decimal Number

				if (deciNum.equals(BigInteger.valueOf(0))) {
					result.add(1 + " " + 0);
				} else {
					List<BigInteger> binaryNum = new ArrayList<BigInteger>();
					while (deciNum.compareTo(BigInteger.valueOf(0)) > 0) {

						binaryNum.add(deciNum.remainder(BigInteger.valueOf(2)));
						deciNum = deciNum.divide(BigInteger.valueOf(2));
					}
					Collections.reverse(binaryNum);
					result.add(getResult(binaryNum)); // Storing all the results in a ArrayList by taking the return
														// value of the method getResult()

				}

			}
		}
		result.forEach(res -> System.out.println(res)); // Printing all the results for each test cases.
	}

	/**
	 * getResult() takes the binary representation as a List and return the result
	 * for each test cases
	 * 
	 * @param binaryNum
	 * 
	 * @return The result for each test cases which is a String
	 */
	private static String getResult(List<BigInteger> binaryNum) {

		int num0 = 0, num1 = 0;
		for (int i = 0; i < binaryNum.size(); i++) {
			for (int j = i; j < binaryNum.size(); j++) {
				int countOfOne = 0, countOfZero = 0;
				for (int k = i; k <= j; k++) {
					if (binaryNum.get(k).equals(BigInteger.valueOf(1)))
						countOfOne++;
					else
						countOfZero++;
				}
				if (countOfOne % 2 != 0)
					num1++;
				if (countOfZero % 2 != 0)
					num0++;
			}

		}

		return num0 + " " + num1; 	/*
									 * Returning the count of substrings with odd number of 0's and substrings with
									 * odd number of 1's in the binary representation of each inputed decimal number
									 */

	}

}

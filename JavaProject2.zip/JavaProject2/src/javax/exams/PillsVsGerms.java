package javax.exams;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PillsVsGerms {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int testNum = 0;
		if (sc.hasNext()) {
			testNum = sc.nextInt(); // Taking input of the number of test cases
		}
		List<Integer> result=new ArrayList<Integer>();
		for(int tc=0;tc<testNum;tc++)
		{
			int m=sc.nextInt();
			int n=sc.nextInt();
			char[][] mtrx=new char[m][n];
			int grm=0;
			for(int i=0;i<m;i++)
			{
				for(int j=0;j<n;j++)
				{
					mtrx[i][j]=sc.next().charAt(0);
					if(mtrx[i][j]=='x')
						grm++;
				}
			}
			
			result.add(getResult(mtrx,m,n,grm));
			
			
		}
	}

	private static Integer getResult(char[][] mtrx, int m, int n, int grm) {
		
		for(int i=0;i<m;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(mtrx[i][j]=='r')
				{
					//if(i>0 && j<)
				}
			}
		}
		
		
		
		return null;
	}
}

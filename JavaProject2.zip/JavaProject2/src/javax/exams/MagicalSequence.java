package javax.exams;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MagicalSequence {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int ntc = sc.nextInt();								/*Taking input of the Number of test cases*/
		List<Integer> result = new ArrayList<Integer>();
		for (int tc = 0; tc < ntc; tc++) {
			int length = sc.nextInt();						/*Taking input of the length of the sequence*/
			sc.nextLine();
			String num = sc.nextLine();						/*Taking input of the sequence as a string*/
			String[] strArry = new String[length];
			strArry = num.split("");
			List<Integer> arrList = new ArrayList<Integer>();
			for (int i = 0; i < strArry.length; i++) {
				arrList.add(Integer.parseInt(strArry[i]));	/*Inputed string is converted to Integer and stored in a Array List*/

			}
			result.add(getResult(arrList));
		}

		result.forEach(rslt -> System.out.println(rslt));	/*Printing the result*/

	}
	
	
	/**
	 *  getResult() takes the inputed sequence as a List and return the result for each test cases
	 * @param arrList
	 * @return Count of magical sequence for each test cases.
	 */
	private static Integer getResult(List<Integer> arrList) {
		int countOfMagicalSequence = 0;
		for (int i = 0; i < arrList.size(); i++) {

			for (int j = i; j < arrList.size(); j++) {
				List<Integer> subSequence = new ArrayList<Integer>();
				for (int l = i; l <= j; l++)
					subSequence.add(arrList.get(l));
				for (int k = subSequence.size() - 2; k >= 0; k -= 2) {
					int twiceOfNum = subSequence.get(k) * 2;
					if (twiceOfNum >= 10) {
						int sumOfTheDigits = 0;
						while (twiceOfNum > 0) {
							sumOfTheDigits = sumOfTheDigits + twiceOfNum % 10;
							twiceOfNum = twiceOfNum / 10;
						}
						subSequence.set(k, sumOfTheDigits);
					} else {
						subSequence.set(k, twiceOfNum);
					}
				}
				int totalSum = 0;
				for (int val : subSequence) {
					totalSum = totalSum + val;
				}
				if (totalSum % 10 == 0)
					countOfMagicalSequence++;

			}

		}
		return countOfMagicalSequence;

	}
}

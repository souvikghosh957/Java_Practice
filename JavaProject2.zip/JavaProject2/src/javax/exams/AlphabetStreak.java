package javax.exams;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class AlphabetStreak {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		String[] strAry=str.split("");
		List<String> arryLst=Arrays.asList(strAry);
		Map<String,Integer> hashMap=new HashMap<String,Integer>();
		int maxCount=1;
		for(int i=0;i<arryLst.size()-1;i++)
		{
			if(!hashMap.containsKey(arryLst.get(i)))
			{
				hashMap.put(arryLst.get(i), 1);
			}
			if(!hashMap.containsKey(arryLst.get(i+1)))
			{
				hashMap.put(arryLst.get(i+1), 1);
			}
			if(arryLst.get(i).equals(arryLst.get(i+1)))
			{
				maxCount++;
				hashMap.put(arryLst.get(i), maxCount);	
			}
			else
			{
				maxCount=1;
				if((hashMap.containsKey(arryLst.get(i)) && (hashMap.get(arryLst.get(i))<=maxCount)))
				hashMap.put(arryLst.get(i), maxCount);	
				if((hashMap.containsKey(arryLst.get(i+1)) && (hashMap.get(arryLst.get(i+1))<=maxCount)))
				hashMap.put(arryLst.get(i+1), maxCount);
							
			}	
			
		}
		
		int max=0;
		String maxKey="";
		for(Map.Entry me : hashMap.entrySet())
		{
			//System.out.println(me.getKey());
			
			if(Integer.valueOf(max).compareTo((Integer) me.getValue())<=0)
			{
				max=(Integer) me.getValue();
								
			}
			
		}
		System.out.println(hashMap);
		String[] maxKeyAry=maxKey.split("");
		List<String> maxKeyAryLst=Arrays.asList(maxKeyAry);
		Collections.sort(maxKeyAryLst);
		String maxKeyRes="";
		for(String st:maxKeyAryLst)
		{
			maxKeyRes=maxKeyRes+st;
		}
		//System.out.println(maxKeyAryLst.toString());
		System.out.println(max+" "+maxKeyRes);
		
	}
	

}

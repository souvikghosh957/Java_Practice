package javax.exams;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PrimeScore {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		long n = sc.nextInt();
		List<Integer> primeDiv = new ArrayList<Integer>();
		List<Long> totalDiv = new ArrayList<Long>();
		totalDiv.add((long)1);
		for (int i = 2; i < n; i++) {
			if (n % i == 0) {
				totalDiv.add((long)i);
				if (isPrime(i))
					primeDiv.add(i);
			}
		}
		totalDiv.add(n);
		long mul = 1;
		for (int i : primeDiv) {
			long count = 0;
			for (long j : totalDiv) {
				if (j % i == 0)
					count++;
			}
			mul = mul * count;
		}
		System.out.println(mul%1000003);
	}

	private static boolean isPrime(int i) {

		for (int j = 2; j < i; j++) {
			if (i % j == 0)
				return false;
		}
		return true;
	}

}

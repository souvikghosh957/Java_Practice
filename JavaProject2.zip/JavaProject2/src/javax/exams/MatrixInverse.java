package javax.exams;
import java.util.Scanner;
 
public class MatrixInverse {
	public static void main(String args[]) {
				
		int i, j;
		int determinant, temp;
		int A[][] = new int[2][2];
		
		Scanner sc = new Scanner(System.in);
		
		for(i = 0; i < 2; ++i)
		{
			for(j = 0; j < 2; ++j)
			{
				A[i][j] = sc.nextInt();
			}
		}
		determinant = (A[0][0] * A[1][1]) - (A[0][1] * A[1][0]);
	
		temp = A[0][0];
		A[0][0] = A[1][1];
		A[1][1] = temp;
		
		A[0][1] = - A[0][1];
		A[1][0] = - A[1][0];
		System.out.println("Case "+1+":");
		for(i = 0; i < 2; ++i) {
			for(j = 0; j < 2; ++j)
			{
				System.out.print((A[i][j]/determinant) + " ");
			}
			System.out.print("\n");
		}
	}
}
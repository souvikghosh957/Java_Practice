package javax.exams;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class MotherChildTshirt {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numOfTestCases = sc.nextInt(); /* Taking input of number of test cases */
		List<List<Integer>> result = new ArrayList<List<Integer>>();
		for (int tc = 0; tc < numOfTestCases; tc++) {
			int nch = sc.nextInt(); /* Taking input of the number of children */
			List<Integer> listOfAges = new ArrayList<Integer>();
			for (int i = 0; i < nch; i++) {
				listOfAges.add(sc.nextInt()); /* Taking input of ages of each children */
			}

			result.add(getResult(listOfAges)); /* Calling the getResult() method to get the required result */

		}

		/**
		 * Printing the result in the required format
		 */
		for (List<Integer> l : result) {
			for (int n : l) {
				System.out.print(n + " ");
			}
			System.out.print("\n");
		}

	}

	/**
	 * The method getResult() returns the number of t-shirt distribution list
	 * 
	 * @param listOfAges as List of Integer
	 * @return listOfTshirts as List of Integer
	 */

	private static List<Integer> getResult(List<Integer> listOfAges) {

		List<Integer> distinctValues = new ArrayList<Integer>();
		distinctValues = listOfAges.stream().distinct().collect(Collectors.toList());
		List<Integer> listOfTshirts = new ArrayList<Integer>();
		Collections.sort(distinctValues);

		for (int i = 0; i < listOfAges.size(); i++)
			listOfTshirts.add(1);

		int tNum = 1;
		for (int i = 1; i < distinctValues.size(); i++) {

			for (int j = 0; j < listOfAges.size(); j++) {
				if (distinctValues.get(i) == listOfAges.get(j)) {

					if (j == 0) {
						if (listOfAges.get(j + 1) < distinctValues.get(i)) {
							tNum = listOfTshirts.get(j + 1) + 1;
							listOfTshirts.set(j, tNum);
						}
					} else if (j == listOfAges.size() - 1) {
						if (listOfAges.get(j - 1) < distinctValues.get(i)) {
							tNum = listOfTshirts.get(j - 1) + 1;
							listOfTshirts.set(j, tNum);

						}
					} else {
						if ((listOfAges.get(j - 1) < distinctValues.get(i))) {
							tNum = (listOfTshirts.get(j - 1) > listOfTshirts.get(j + 1) ? listOfTshirts.get(j - 1)
									: listOfTshirts.get(j + 1)) + 1;
							listOfTshirts.set(j, tNum);
						} else if (listOfAges.get(j + 1) < distinctValues.get(i)) {

							tNum = listOfTshirts.get(j + 1) + 1;
							listOfTshirts.set(j, tNum);

						}

					}

				}

			}
		}

		return listOfTshirts;
	}
}

package javax.exams;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class CommonPrimeNumber {

	
	    public static void main(String[] args) throws IOException {
	         BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	         PrintWriter wr = new PrintWriter(System.out);
	         String[] arr_A1 = br.readLine().split(" ");
	         long A = Long.parseLong(arr_A1[0]);
	         long B = Long.parseLong(arr_A1[1]);
	         long out_ = solve(A, B);
	         System.out.println(out_);

	         wr.close();
	         br.close();
	    }
	    
	    static long solve(long A, long B)
	    {  
	        for(int i=2;i<=Math.max(A,B);i++)
	        {
	            if(A%i==0 && B%i==0)
	            {
	                if(isPrime(i))
	                {
	                    return i;
	                }
	            }
	        }
	        return -1;
	        
	    }
	    
	    static boolean isPrime(long n)
	    {
	        for(long i=2;i<n;i++)
	        {
	            if(n%i==0)
	            {
	                return false;
	            }
	        }
	        return true;
	    }
}

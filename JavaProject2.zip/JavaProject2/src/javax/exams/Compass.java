package javax.exams;

import java.util.Scanner;

public class Compass {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int current = sc.nextInt();
		int correct = sc.nextInt();
		int movement = 0;

		int diff = correct - current;

		if (diff > 180) {
			movement = (360 - diff) * -1;
		} else if (diff < -180) {
			movement = 360 + diff;
		} else if (Math.abs(diff) == 180) {
			movement = 180;
		} else {
			movement = diff;
		}
		System.out.println(movement);
	}
}

package javax.exams;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class KingsMerch {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int testNum = 0;
		if (sc.hasNext()) {
			testNum = sc.nextInt(); // Taking input of the number of test cases
		}
		for(int tc=0;tc<testNum;tc++)
		{
			int n=sc.nextInt();
			char[][] mtrx=new char[n][n];
			for(int i=0;i<n;i++)
			{
				for(int j=0;j<n;j++)
				{
					mtrx[i][j]=sc.next().charAt(0);
				}
			}
		
	}

}
}
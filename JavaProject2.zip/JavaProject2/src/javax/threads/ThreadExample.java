package javax.threads;

public class ThreadExample extends Thread{

	public void run()	
	{
			for(int i=1;i<=10;i++)
	{
				try
				{
					Thread.sleep(1000);
				}
				catch(InterruptedException ie){
					
				}

		System.out.println(i);
	}
	 System.out.println("Thread is getting executed");
	}
	
	
	public static void main(String[] args) {
		
		ThreadExample te=new ThreadExample();
		ThreadExample te1=new ThreadExample();
		
		te.start();
/*		try {
		te.yield();;
		}
		catch(InterruptedException ie)
		{
			System.out.println("");
		}
*/		
		te1.start();
		//te.start();
		
	}

}

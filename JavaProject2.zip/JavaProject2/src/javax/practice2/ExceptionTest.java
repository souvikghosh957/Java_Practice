package javax.practice2;

public class ExceptionTest {
	
	public static void main(String[] args) {
		
		System.out.println(methodOne());
		
	}
	
	public static int methodOne()
	{
		try {
			throw new Exception();
		}
		catch(Exception e){
			return 4;
		}
		finally
		{
			return 3;
		}
	}

}

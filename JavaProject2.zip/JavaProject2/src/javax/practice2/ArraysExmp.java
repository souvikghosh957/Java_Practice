package javax.practice2;

import java.util.Arrays;
import java.util.List;

public class ArraysExmp {
	
	public static void main(String args[])
	{
		int[] ar1 =new int[] {2,3,4};
		int[] ar2= new int[] {3,4,5};
		int[] rest=getResult(ar1,ar2);
		/*List<int[]> arlst=Arrays.asList(getResult(ar1,ar2));
		arlst.forEach(n->System.out.println(n));*/
		for(int i=0; i<rest.length;i++)		
		{
			System.out.print(rest[i]);
		}
	}

	private static int[] getResult(int[] ar1, int[] ar2) {
		
		int[] res=new int[3];
		int c=-1;
		for(int i=0;i<ar1.length;i++)
		{
			for(int j=0;j<ar2.length;j++)
			{
				if(ar1[i]==ar2[j])
				{
					c++;
					res[c]=ar2[j];
					
				}
			}
		}
		
		return res;
				
	}

}

package javax.practice2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;
import java.util.stream.Stream;

public class StaticBlock {

	static
	{
		System.out.println("Hello!! Inside Static Block");
	}
	
	{
		System.out.println("Hello!! Inside Instance Block");
	}

	Collections cl;
	String str;
	Comparable<String> ct;
	Comparator<String> ct1;
	Object obj;
	Arrays ary;
	Collection c;
	List l;
	ArrayList ar;
	LinkedList ll;
	Set s;
	HashSet hs;
	HashMap hm;
	Queue q;
	Stack st;
	Number num;
	public static void main(String[] args) {
		StaticBlock sb=new StaticBlock();
	}
}


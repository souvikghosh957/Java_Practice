package javax.practice2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class DemoList {
	
	public static void main(String[] args) {
		
		Integer[] p=new Integer[] {3,4,5,7,6};
		
		List<Integer> arLst=Arrays.asList(1,3,4,7);
		List<Integer> arLst2=Arrays.asList(p);
		System.out.println(arLst2);
		
		List<Integer> arryList=new ArrayList<Integer>();
		List<Integer> linkedList=new LinkedList<Integer>();
		arryList.addAll(arLst);
		linkedList.addAll(arLst);
		System.out.println(arryList);
		System.out.println(linkedList);
		
		Iterator itr=arryList.iterator();
		ListIterator lsitr=arryList.listIterator(arryList.size());
		while(itr.hasNext())
		{
			System.out.print(itr.next()+" ");
		}
		System.out.println("\n");
		while(lsitr.hasPrevious())
		{
			System.out.print(lsitr.previous()+" ");
		}

		
	}

}

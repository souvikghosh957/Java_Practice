package javax.practice2;

public class ExceptionDemo {

	public static void main(String[] args) {

		try {
			int a = 10 / 0;
			
			
		} catch (RuntimeException e) {

			e.printStackTrace();
		}
		finally {

			System.out.println("Inside finally");
		}

	}
}

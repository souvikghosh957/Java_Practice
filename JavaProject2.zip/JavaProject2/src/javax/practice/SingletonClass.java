package javax.practice;

public class SingletonClass {

	/*
	 * private SingletonClass() {
	 * 
	 * }
	 * 
	 * static SingletonClass instance=new SingletonClass();
	 * 
	 * public static SingletonClass getInstance() { return instance; }
	 */

	private SingletonClass() {

	}

	static SingletonClass instance;

	public static SingletonClass getInstance() {

		if (instance == null) {
			instance = new SingletonClass();
		}
		return instance;
	}

}

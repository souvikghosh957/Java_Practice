package javax.practice;

public class MultiThreadingDemo extends Thread implements Runnable {
	
	
	public void run()
	{
		System.out.println("This is "+Thread.currentThread());

		for(int i=0;i<5;i++)
		{
			try
			{
			Thread.sleep(500);
			}
			catch(Exception ex)
			{
				System.out.println(ex);
			}
			System.out.println("This is "+Thread.currentThread());

		}
		
	}
	
	
	
	
	public static void main(String[] args) {
		
		MultiThreadingDemo mt=new MultiThreadingDemo();
		Thread th=new Thread(new  MultiThreadingDemo());
		mt.setDaemon(true);
		mt.start();
		//mt.setDaemon(true);
		//th.start();
		
		
	}

}

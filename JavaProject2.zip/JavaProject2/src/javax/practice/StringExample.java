package javax.practice;

public class StringExample {
	static String str1="Souvik";
	public static void main(String[] args) {
		
		String str3=new String("Souvik");
		String str4=new String("Souvikk");
		String str2="Souvik";
		System.out.println(str2.equals(str1));
		System.out.println(str2==str1);
		System.out.println(str3==str4);
		System.out.println(str3.compareTo(str4));
		
	}
}

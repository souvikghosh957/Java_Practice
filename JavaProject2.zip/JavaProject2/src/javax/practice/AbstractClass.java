package javax.practice;

public abstract class AbstractClass {

	void method1()
	{
		System.out.println("Inside method1");
	}
	
	abstract void method2();
	
	public static void main(String[] args) 
	{
		//AbstractClass abstractClass=new AbstractClass();
		
	}
}

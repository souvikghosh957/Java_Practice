package javax.practice;

public class MainClass {

	static final int x=0;
	strictfp void method1()
	{
		System.out.println("Value of  x="+x);
	}
	
	public static void main(String[] args) {
		
		/*MainClass mainClass=new MainClass();
		mainClass.method1();
		System.out.println(x);*/
		
		SingletonClass stc=SingletonClass.getInstance();
		System.out.println(stc.hashCode()); //output 2018699554
		SingletonClass stc2=SingletonClass.getInstance();
		System.out.println(stc2.hashCode());
		boolean[] array = new boolean[3];
		System.out.println(array[1]);
		
		
	}
}

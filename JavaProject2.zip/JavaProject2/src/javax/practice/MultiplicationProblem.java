package javax.practice;

import java.util.Scanner;

public class MultiplicationProblem {

	public static void main(String[] args) {
		 Scanner sc=new Scanner(System.in);
		 int number=sc.nextInt();
		 int mul=1;
		 while(number>0)
		 {
			 int r=number%10;
			 if(r==0)
			 {
				 
			 }
			 mul=mul*r;
			 number=number/10;
			 
		 }
		 System.out.println("Result------------="+mul);
	}

	
}

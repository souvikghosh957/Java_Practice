package javax.practice;

public class ObjectComparition {

	public static void main(String[] args) {
		
	}
}

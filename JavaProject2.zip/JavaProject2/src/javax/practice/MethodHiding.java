package javax.practice;


class SuperClass
{
	
	public static void methodOne()
	{
		System.out.println("Inside Super Class Method");
	}

}
public class MethodHiding extends SuperClass{
	
	public static void methodOne()
	{
		System.out.println("Inside Child Class Method");
	}

	public static void main(String[] args) {
		MethodHiding mH=new MethodHiding();
		mH.methodOne();
		SuperClass mH3=new MethodHiding();
		mH3.methodOne();
		SuperClass mH2=null;
		mH2.methodOne();
		//ChildClass.methodOne();
	}
}

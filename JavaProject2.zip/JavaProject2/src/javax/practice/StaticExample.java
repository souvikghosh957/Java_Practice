package javax.practice;

 class StaticExampleOne {
	
	public void methodOne()
	{
		System.out.println("Method 1");
	}
	

}
 class StaticExampleTwo extends StaticExampleOne{
	
	public void methodOne()
	{
		System.out.println("Method 2");
	}
	

}
 
 public class StaticExample{
		
	 public static void main(String[] args) {
		 StaticExampleOne staticExampleOne=new StaticExampleTwo();
		 staticExampleOne.methodOne();
	}
	 
}

package javax.practice.problems;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class SubArrayOfGivenNumbers {

	public static void main(String[] args) 
	{
		final Map<Integer,Integer> map=new HashMap<Integer,Integer>();
		map.put(1, 100);
		map.put(2, 101);
		map.put(1, 102);
		System.out.println(map);
		
		Scanner sc=new Scanner(System.in);
		int ntc=sc.nextInt();
		for(int i=0;i<ntc;i++)
		{
			
			int[] arr0=new int[2];
			for(int j=0;j<2;j++)
			{
				arr0[j]=sc.nextInt();
			}
			int[] arry=new int[arr0[0]];
			for(int j=0;j<arr0[0];j++)
			{
				arry[j]=sc.nextInt();
			}
			if(i==0)
				System.out.println("\n");
		 getResult(arr0,arry);
		}
		
		
		
	}

	private static void getResult(int[] arr0, int[] arry) {
		
		for(int i=0;i<arry.length;i++)
		{	int flag=0;
			int sum=0;
			for(int j=i;j<arry.length;j++)
			{
				sum=sum+arry[j];
				if(sum==arr0[1])
				{
					System.out.print((i+1)+" "+(j+1));
					flag=1;
					break;
				}
							
			}
			if(flag==1)
				break;
			else if(i==arry.length-1)
				System.out.println(-1);

			
			
		}
		
		
	}
}

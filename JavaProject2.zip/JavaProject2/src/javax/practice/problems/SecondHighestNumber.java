package javax.practice.problems;

public class SecondHighestNumber {

	public static void main(String[] args) {
		
		int[] a=new int[] {8, 3, 11, 7};
		int large=0;
		int secondLarge=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]>large)
			{
				secondLarge=large;
				large=a[i];
			}
			else if(a[i]>secondLarge && a[i]<large)
			{
				secondLarge=a[i];
			}
			
		}
		System.out.println(large+" "+secondLarge);
		
	}
}

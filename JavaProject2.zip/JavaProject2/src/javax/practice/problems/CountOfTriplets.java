package javax.practice.problems;

import java.util.Scanner;

public class CountOfTriplets
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int not=sc.nextInt();
		for(int i=0;i<not;i++)
		{
			int arrlen=sc.nextInt();
			int[] arry=new int[arrlen];
			for(int j=0;j<arry.length;j++)
			{
				arry[j]=sc.nextInt();
			}
			
			getResult(arry);
		}
		
		
	}

	private static void getResult(int[] arry) {

		for(int i=0;i<arry.length-2;i++)
		{
			int l=i+1;
			int k=arry.length-1;
			
			while(l<k)
			{
				System.out.println(arry[i]+" "+arry[l]+" "+arry[k]);
				
				l++;
				k--;
				
				
			}
			
			
			
		}
		
		
		
		
	}
	
	
}

package javax.practice.problems;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class KadanesAlgorithim {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		List<Integer> result=new ArrayList<Integer>();
		int testCases=sc.nextInt();
		for(int tc=0;tc<testCases;tc++)
		{
			int size=sc.nextInt();
			int[] arry=new int[size];
			for(int i=0;i<arry.length;i++)
			{
				arry[i]=sc.nextInt();
			}
			result.add(getResult(arry));
		}
		result.forEach(n->System.out.println());
	}

	private static Integer getResult(int[] arry) {
		
		
		
		
		return null;
	}

}

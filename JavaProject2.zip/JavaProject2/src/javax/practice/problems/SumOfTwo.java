package javax.practice.problems;

import java.util.HashMap;
import java.util.Map;

public class SumOfTwo {

	public static void main(String[] args) {

		int[] a = new int[] { 4, 6, 7, 5, 9, 12, 2 };
		int sum = 14;
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		for (int i = 0; i < a.length; i++) {
			int delta = sum - a[i];
			if (map.containsKey(delta)) {
				System.out.println("Indexes are: "+i + " " + " " + map.get(delta));
				//break;
			}

			map.put(a[i], i);
		}
	}

}

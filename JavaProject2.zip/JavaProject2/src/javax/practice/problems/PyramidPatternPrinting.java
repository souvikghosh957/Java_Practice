package javax.practice.problems;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class PyramidPatternPrinting {
	static int count=0;
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int testCases=sc.nextInt();
		for(int tc=0;tc<testCases;tc++)
		{
			sc.nextLine();
			String str=sc.nextLine();
			int h=sc.nextInt();
			int dir=sc.nextInt();
			String[] a=str.split("");
			List<String> al=Arrays.asList(a);
			getResult(al,h,dir);
			
		}
		

	}

	private static void getResult(List<String> al, int h, int dir) {
		
		for(int i=0;i<h;i++)
		{
			for(int j=0;j<h-i;j++)
			{
				System.out.print(" ");
			}
			
			for(int k=0;k<2*i+1;k++)
			{
				//System.out.print("*");
				getListVal(al,count++);
			}
			System.out.print("\n");
		}
		
		
	}
	
	 private static String getListVal(List<String> al,int count)
	 {
		 Iterator it;
		 if(count%(al.size())==0)
		 {
		    it=al.iterator();

		 }
		 else
		 {
			  it=al.listIterator(count);

		 }
		 if(it.hasNext())
				return it.next().toString();
		 else
			 return "";
	 }
}
		/*String s="abc";
		String[] a=s.split("");
		List<String> al=Arrays.asList(a);
	    
		for(int i=0;i<6;i++)
		{
			for(int j=0;j<6-i;j++)
			{
				int k=j;
				if(k>2)
				{
					k=0;
				}
				System.out.print(" ");
			}
			
			for(int j=0;j<2*i-1;j++)
			{
				int k=j;
				if(j>=2)
				{
					j=0;
				}
				int k=j;
				if(k>=a.length-1)
					k=0;
				System.out.print(a[k]);
	
			}
			System.out.println("\n");
		}
	}*/
//}
	 

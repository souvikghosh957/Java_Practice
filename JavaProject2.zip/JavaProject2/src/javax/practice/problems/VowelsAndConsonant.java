package javax.practice.problems;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class VowelsAndConsonant {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int testC = sc.nextInt();
		List<Integer> result = new ArrayList<Integer>();
		for (int i = 0; i < testC; i++) {
			int size = sc.nextInt();
			sc.nextLine();
			String s = sc.nextLine();
			char[] charSeq = s.toCharArray();
			result.add(getResult(charSeq));

		}
		result.forEach(n -> System.out.println(n));
	}

	private static Integer getResult(char[] charSeq) {
		int count = 0;
		for (int i = 0; i < charSeq.length; i++) {
			for (int j = i + 1; j < charSeq.length; j++) {
				int c = 0;
				int flag = 0;
				for (int k = i; k <= j; k++) {

					if (charSeq[k] == 'a' || charSeq[k] == 'e' || charSeq[k] == 'i' || charSeq[k] == 'o'
							|| charSeq[k] == 'u') {
						flag++;
					}
				/*	if (charSeq[k] != 'a' && charSeq[k] != 'e' && charSeq[k] != 'i' && charSeq[k] != 'o'
							&& charSeq[k] != 'u') {
						flag--;
					}*/
				/*	if (k == i) {
						continue;
					} else if (flag == 0) {
						count++;
						continue;
					} else {
						c = 1;
						break;
					}*/
				}
				if (c == 1)
					break;

			}
		}
		return count;
	}
}

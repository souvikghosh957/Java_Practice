package javax.practice;

public class Polymorphism {
	
	

}
